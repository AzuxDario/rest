app.controller('HomeController', function($scope){
	$scope.message = 'Hello HomeController';
});